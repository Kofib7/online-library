Use library;
#user
insert into user values (001, 'jack', 'mann', 'jm@gmail.com', 'USA', 'boom14', '2006-02-13', '2006-05-20'); 
insert into user (firstname, lastname, email, country, password, date_created, date_modified) values ('jimmy', 'lin', 'lj@yahoo.com', 'Korea', 'jkl7', '2017-07-13', '2018-01-10');
insert into user (firstname, lastname, email, country, password, date_created, date_modified) values ('kwame', 'gyan', 'kgyan@yahoo.com', 'Ghana', '987trt', '2010-09-23', '2010-12-12');
insert into user (firstname, lastname, email, country, password, date_created, date_modified) values ('kim', 'lee', 'leek@gmail.com', 'China', 'luro9', '2012-06-08', '2014-04-26');
insert into user (firstname, lastname, email, country, password, date_created, date_modified) values ('motumbo', 'usman', 'muus@yahoo.com', 'Kenya', 'insi453', '2006-01-13', '2006-03-14');
insert into user (firstname, lastname, email, country, password, date_created, date_modified) values ('aaron', 'mark', 'aam@hotmail.com', 'England', 'jhgf18', '2011-03-13', '2011-06-19');
insert into user (firstname, lastname, email, country, password, date_created, date_modified) values ('hariet', 'masa', 'hamas@gmail.com', 'Sudan', 'bull23', '2013-06-13', '2013-07-03');
insert into user (firstname, lastname, email, country, password, date_created, date_modified) values ('talson', 'ingram', 'bigie@yahoo.com', 'India', 'anbr9s', '2017-04-13', '2017-05-02');
insert into user (firstname, lastname, email, country, password, date_created, date_modified) values ('grace', 'otu', 'grotu@outlook.com', 'Ghana', 'mivk98', '2009-05-13', '2018-02-18');
insert into user (firstname, lastname, email, country, password, date_created, date_modified) values ('jason', 'clarke', 'papa1@yahoo.com', 'England', '123abc', '2018-03-13', '2018-06-23');

#books
insert into books values ('Jungle Man', 'J.K Manny', 484887527, 100);
insert into books (title, author, isbn) values ('The Spider', 'Samuel Doby', 890347538);
insert into books (title, author, isbn) values ('War', 'S.E Chan', 099473943);
insert into books (title, author, isbn) values ('Guns Today', 'Gen. Abrafi', 573532184);
insert into books (title, author, isbn) values ('13 reasons', 'A.J Tracey', 184324909);
insert into books (title, author, isbn) values ('Unit 1', 'Prof. Troy', 747054399);
insert into books (title, author, isbn) values ('Cross', 'D.Y Chance', 563859365);
insert into books (title, author, isbn) values ('The Magic Pot', 'K. Odunsi', 123456780);
insert into books (title, author, isbn) values ('The Rave', 'Dr. Kim', 479613473);

insert into books (title, author, isbn) values ('Team Work', 'Dr. Cho', 403677899);
insert into books (title, author, isbn) values ('Inside History', 'Dr. Otu', 225689765);
insert into books (title, author, isbn) values ('One time', 'Mr. Acquaye', 320209531);
insert into books (title, author, isbn) values ('Excellency', 'D.L Hart', 104321286);
insert into books (title, author, isbn) values ('The Point', 'Dr. Shims', 185432349);
insert into books (title, author, isbn) values ('A Hunter', 'Mr. Musa', 987613452);

#borrowed books
insert into borrowed_books  values (001,103,'2013-05-20','2013-06-12');
insert into borrowed_books  values (004,107,'2013-09-06','2013-10-03');
insert into borrowed_books  values (001,107,'2015-12-21','2015-12-30');
insert into borrowed_books  values (005,106,'2009-11-26','2009-12-07');
insert into borrowed_books  values (007,108,'2015-05-06','2015-06-01');

alter table borrowed_books add column comments varchar(60);

select * from borrowed_books;
