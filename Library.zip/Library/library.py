from flask import Flask, jsonify, request, redirect, url_for, session, render_template
from flask_mysqldb import MySQL
import datetime
import os 
import jwt
from functools import wraps

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secretkey'
app.secret_key = jwt.encode({'exp' : datetime.datetime.utcnow() + datetime.timedelta()}, app.config['SECRET_KEY']) #Encoding token for api security 

#MySQL application 
mysql = MySQL(app)

#Access to the library database
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'library'

#Token validation for API security
def token_required(f):
	@wraps(f)
	def decorated(*args, **kwargs):
		token = request.args.get('token')

		if not 'token':
			return jsonify({'message' : 'Token is missing!'}), 403

		try:
			data = jwt.decode(token, app.config['SECRET_KEY'])
		except:
			return jsonify({'message' : 'Invalid token'}), 403

		return f(*args, **kwargs)

	return decorated

###########################################################################################################

#Signup endpoint 
@app.route('/signup' , methods = ['GET','POST'])
def signup():
	if request.method == 'POST':
		session['token'] = request.args.get(app.secret_key.decode('UTF-8'))
		firstname = request.form['firstname']
		lastname = request.form['lastname']
		email = request.form['email']
		country = request.form['country']
		password = request.form['password']
		tur = mysql.connection.cursor()
		dets = tur.execute('INSERT INTO user(firstname, lastname, email, country, password) Values("%s", "%s", "%s", "%s","%s")'%(firstname, lastname, email, country, password))
		mysql.connection.commit()
		tur.execute('SELECT * FROM user WHERE email = ("%s")'%email)
		Data = tur.fetchall()
		return jsonify({'ResponseMessage' : 'Signup Successful' , 'Responsecode' : '200'}, {'Data' : Data})

	return render_template('signup.html')
	   	
#############################################################################################################

#Login endpoint
@app.route('/login', methods = ['GET','POST'])
def login():
	if request.method == 'POST':
		email = request.form['email']
		password = request.form['password']
		tur = mysql.connection.cursor()
		if (tur.execute('SELECT email, password FROM user WHERE email = ("%s") AND password = ("%s")'%(email, password))):
			Data = tur.fetchone()
			session['token'] = request.args.get(app.secret_key.decode('UTF-8')) 
			return jsonify({'ResponseMessage' : 'Login Successful' , 'Responsecode' : '200'} , {'Data' : Data})
		else:
			return jsonify({'error' : 'Unable to Login!'})
		
	return render_template('login.html')
	
#############################################################################################################

#Endpoint for updating user details
@app.route('/userdetails', methods = ['GET','POST','PUT'])
def update():
	if 'token' in session and request.method == 'POST':
		fname = request.form['firstname']
		lname = request.form['lastname']
		email = request.form['email']
		country = request.form['country']
		password = request.form['password']
		tur = mysql.connection.cursor()
		detupdt = tur.execute('UPDATE user SET firstname = ("%s"), lastname = ("%s"), email = ("%s"), country = ("%s"), password = ("%s") WHERE email = ("%s")'%(fname, lname, email, country, password))
		mysql.connection.commit()
		tur.execute('SELECT * FROM user WHERE email = ("%s")'%email)
		Data = tur.fetchall()
		return jsonify({'ResponseMessage' : 'Update Successful' , 'Responsecode' : '200'}, {'Data' : Data})
	
	return render_template('change.html')

##############################################################################################################

#Endpoint for getting all books
@app.route('/library', methods = ['GET'])
def books():
	if 'token' in session:
		tur = mysql.connection.cursor()
		bks_display = tur.execute("SELECT  * FROM books")	
		Data = tur.fetchall()
		return jsonify({'ResponseMessage' : 'Successful' , 'Responsecode' : '200'}, {'Data' : Data})

	return jsonify({'message' : 'Invalid Token!'})

##############################################################################################################

#Endpoint for getting one book
@app.route('/library/<string:title>', methods = ['GET'])
def read(title):
	if 'token' in session:
		tur = mysql.connection.cursor()
		read = tur.execute('SELECT * FROM books WHERE title = "%s"'%title)
		Data = tur.fetchone()
		return jsonify({'ResponseMessage' : 'Successful' , 'Responsecode' : '200'}, {'Data' : Data})
	
	return jsonify({'message' : 'Invalid Token!'})

###############################################################################################################

#Endpoint for borrowing a book
@app.route('/library/borrowbook/<id>', methods = ['GET'])
def borrowbook(id):
	if 'token' in session:
		tur = mysql.connection.cursor()
		tur.execute('INSERT INTO borrowed_books(book_id) SELECT id FROM books WHERE id = ("%s")')
		mysql.connection.commit()
		brwbk = tur.execute('SELECT * FROM books WHERE id = ("%s")'%id)
		Data = tur.fetchone()
		return jsonify({'ResponseMessage' : 'Successful' , 'Responsecode' : '200'}, {'Data' : Data})

	return jsonify({'message' : 'Invalid Token!'})

################################################################################################################

#Endpoint for returning 
@app.route('/library/returnbook/<book_id>', methods = ['GET','POST'])
def returnbook(book_id):
	if 'token' in session:
		tur = mysql.connection.cursor()
		tur.execute('INSERT INTO borrowed_books(book_id) SELECT id FROM books WHERE id = ("%s")')
		mysql.connection.commit()
		tur.execute('SELECT * FROM borrowed_books WHERE book_id = (%s)'%book_id)
		Data = tur.fetchall()
		return jsonify({'ResponseMessage' : 'Return Successful' , 'Responsecode' : '200'}, {'Data' : Data})

	return jsonify({'message':'Invalid Token'})

################################################################################################################

#Endpoint for commenting
@app.route('/comments', methods = ['GET', 'POST'])
def comments():
	if 'token' in session and request.method == 'POST':
		user_id = request.form['user_id']
		book_id = request.form['book_id']
		comments = request.form['comments']
		tur = mysql.connection.cursor()
		tur.execute('INSERT INTO borrowed_books(user_id, book_id, comments) Values("%s", "%s", "%s")'%(user_id, book_id, comments))
		mysql.connection.commit()
		tur.execute('SELECT user_id, book_id, comments FROM borrowed_books WHERE comments = "%s"'%comments)
		Data = tur.fetchall()
		return jsonify({'ResponseMessage' : 'Input Successful' , 'Responsecode' : '200'}, {'Data' : Data})

	return render_template('comment.html')

#################################################################################################################

#Logout Endpoint
@app.route('/logout')
def logout():
	session.pop('token', None)
	return jsonify({'message' : 'Logged out'})

################################################################

if __name__ == '__main__':
	app.run(debug = True) 